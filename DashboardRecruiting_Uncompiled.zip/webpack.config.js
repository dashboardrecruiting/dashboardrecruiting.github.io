var debug = process.env.NODE_ENV !== "production";
var webpack = require('webpack');
const path = require('path');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const autoprefixer = require('autoprefixer');

const javascript = {
  test: /\.(js)$/,
  use: [{
    loader: 'babel-loader',
    options: { presets: ['es2015'] }
  }]
};

const postcss = {
  loader: 'postcss-loader',
  options: {
    plugins() { return [autoprefixer({ browsers: 'last 3 versions' })]; },
    sourceMap: true
  }
};

const styles = {
  test: /\.(scss)$/,
  use: ExtractTextPlugin.extract(['css-loader?sourceMap', postcss, 'sass-loader?sourceMap', 'resolve-url-loader'])
};

const images = {
  test: /\.(png|jpg|jpeg)$/,
  loader: 'url-loader',
  query: {
    limit: 8192
  }
}

const uglify = new webpack.optimize.UglifyJsPlugin({
  compress: { warnings: false },
  comments: false
});

const config = {
  entry: './assets/js/app.js',
  devtool: debug ? 'source-map' : false,
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: 'scripts.bundle.js'
  },
  module: {
    rules: [javascript, images, styles]
  },
  plugins: [
    new ExtractTextPlugin('style.css'),
    new webpack.optimize.AggressiveMergingPlugin(),
    uglify
  ]
};

process.noDeprecation = true;

module.exports = config;
