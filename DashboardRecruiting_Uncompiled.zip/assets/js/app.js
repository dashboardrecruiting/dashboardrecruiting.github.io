import '../sass/style.scss';

const $ = require('jquery');
window.jQuery = $;
const pagepiling = require('pagepiling.js');

$(() => {

  let autopager;
  const delay = 10000;

  function nextPage() {
    $.fn.pagepiling.moveSectionDown();
  };

  function startAutopager() {
    autopager = setTimeout(nextPage, delay);
  };

  function stopAutopager(i) {
    clearTimeout(i)
  };

  $('#pagepiling').pagepiling({
    menu: '#menu',
    direction: 'vertical',
    anchors: ['dash-advantage', 'in-house', 'partners', 'associates', 'contact-us'],
    navigation: {
      'textColor': '#ffffff',
      'bulletsColor': '#ffffff',
      'position': 'right',
      'tooltips': ['Dash Advantage', 'In-House', 'Partners', 'Associates', 'Contact Us']
    },
    sectionsColor: ['#333333', '#252525', '#000000', '#000000', '#000000' ],
    normalScrollElements: '.scrollable',
    loopBottom: 'true',
    onLeave: function (index, nextIndex, direction) {
      //fading out the txt of the leaving section
      $('.section').eq(index - 1).find('.contents').fadeOut(1000, 'easeInQuart');
      //fading in the text of the destination (in case it was fadedOut)
      $('.section').eq(nextIndex - 1).find('.contents').fadeIn(1000, 'easeInQuart');
    },
    afterLoad: function(anchorLink, index) {
      startAutopager();
    },
    onLeave: function(index, nextIndex, direction) {
      stopAutopager(autopager);
    },
    afterRender: function() {
      startAutopager();
    }
  });

  $('body').on('click', function() {
    stopAutopager(autopager);
  });

});

// FADE IN SITE ON PAGE LOAD
$(window).on("load", function() {
  $(".site-fadein").fadeOut("slow");
});
